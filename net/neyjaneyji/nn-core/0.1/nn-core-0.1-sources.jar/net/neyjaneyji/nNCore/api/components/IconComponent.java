package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * A component that displays a Minecraft material as a small 3D icon in the GUI.
 */
public class IconComponent implements GUIComponent {

    private final Material material;
    private ItemDisplay display;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;

    /**
     * Constructs an IconComponent from a specified material.
     *
     * @param material The Material type of the item to display as an icon.
     */
    public IconComponent(Material material) {
        this.material = material;
    }

    /**
     * Spawns an ItemDisplay entity representing the icon.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        this.display = (ItemDisplay) parent.getOrigin().getWorld().spawnEntity(
                parent.getPixelLocation(x, y), EntityType.ITEM_DISPLAY);

        display.setItemStack(new ItemStack(material));
        entities.add(display);
    }

    /**
     * Updates the location of the icon display entity.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override
    public void updateLocation(double x, double y) {
        if (display != null) display.teleport(parent.getPixelLocation(x, y));
    }

    /** No interaction handling directly on the icon */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the icon */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets the ItemDisplay entity for this icon.
     *
     * @return A list containing the ItemDisplay entity.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
