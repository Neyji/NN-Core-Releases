package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A search bar component that prompts the player for input via chat when clicked.
 */
public class SearchBarComponent implements GUIComponent {
    private String query = "";
    private final TextComponent display;
    private final HitboxComponent hitbox;
    private final List<Entity> entities = new ArrayList<>();
    private final Consumer<String> onSearch;

    /**
     * Constructs a SearchBarComponent.
     *
     * @param placeholder The placeholder text to display before a query is entered.
     * @param onSearch A callback function executed when the query is updated. Provides the query string.
     */
    public SearchBarComponent(String placeholder, Consumer<String> onSearch) {
        this.onSearch = onSearch;
        this.display = new TextComponent("§8" + placeholder);
        this.hitbox = new HitboxComponent(1.5f, 0.3f, p -> {
            p.sendMessage("§b[NN Core] §7Type your search query in chat:");
            // Here you would normally register a listener to catch the next chat message
            // For now, we'll simulate the update
        });
    }

    /**
     * Updates the query string, refreshes the display, and triggers the search callback.
     *
     * @param newQuery The new query string to set.
     */
    public void updateQuery(String newQuery) {
        this.query = newQuery;
        this.display.setText("§f" + query + "§b|");
        onSearch.accept(query);
    }

    /**
     * Spawns the search bar display and its interaction hitbox.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        display.spawn(parent, x, y);
        hitbox.spawn(parent, x, y);
        entities.addAll(display.getEntities());
        entities.addAll(hitbox.getEntities());
    }

    /**
     * Updates the location of the search bar components.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) {
        display.updateLocation(x, y);
        hitbox.updateLocation(x, y);
    }

    /**
     * Triggers the hitbox click logic, prompting the user for input.
     *
     * @param player The player clicking the search bar.
     */
    @Override public void onClick(Player player) { hitbox.onClick(player); }

    /** No hover logic directly on the search bar */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this search bar.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
