package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * An interactive dropdown menu component that displays a list of options when clicked.
 */
public class DropdownComponent implements GUIComponent {
    private final List<String> options;
    private String selectedValue;
    private boolean expanded = false;

    private final TextComponent mainDisplay;
    private final HitboxComponent mainHitbox;
    private final List<ButtonComponent> optionButtons = new ArrayList<>();

    private final List<Entity> entities = new ArrayList<>();
    private final Consumer<String> onSelect;
    private NNCoreGUI parent;
    private double lastX, lastY;

    /**
     * Constructs a DropdownComponent.
     *
     * @param options A list of string options to display in the dropdown.
     * @param defaultText The initial text displayed before an option is selected.
     * @param onSelect A callback function executed when an option is selected.
     */
    public DropdownComponent(List<String> options, String defaultText, Consumer<String> onSelect) {
        this.options = options;
        this.selectedValue = defaultText;
        this.onSelect = onSelect;

        this.mainDisplay = new TextComponent("§f" + selectedValue + " §7▼");
        this.mainHitbox = new HitboxComponent(1.2f, 0.3f, p -> toggle(p));
    }

    /**
     * Toggles the expanded state of the dropdown, showing or hiding options.
     *
     * @param player The player interacting with the dropdown.
     */
    private void toggle(Player player) {
        this.expanded = !this.expanded;
        if (expanded) {
            showOptions();
        } else {
            hideOptions();
        }
        this.mainDisplay.setText("§f" + selectedValue + (expanded ? " §b▲" : " §7▼"));
    }

    /**
     * Renders the dropdown options below the main display.
     */
    private void showOptions() {
        double currentY = lastY + 12; // Start appearing below the main bar
        for (String opt : options) {
            ButtonComponent btn = new ButtonComponent("§7" + opt, 1.0f, 0.25f, p -> {
                this.selectedValue = opt;
                this.onSelect.accept(opt);
                toggle(p); // Collapse after selection
            });
            btn.spawn(parent, lastX, currentY);
            optionButtons.add(btn);
            entities.addAll(btn.getEntities());
            currentY += 8;
        }
    }

    /**
     * Hides the dropdown options and removes their entities.
     */
    private void hideOptions() {
        for (ButtonComponent btn : optionButtons) {
            btn.getEntities().forEach(Entity::remove);
        }
        entities.removeAll(entities); // Clear internal list
        // Re-add the main components to entities
        entities.addAll(mainDisplay.getEntities());
        entities.addAll(mainHitbox.getEntities());
        optionButtons.clear();
    }

    /**
     * Spawns the main dropdown display and hitbox.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        this.lastX = x;
        this.lastY = y;

        mainDisplay.spawn(parent, x, y);
        mainHitbox.spawn(parent, x, y);

        entities.addAll(mainDisplay.getEntities());
        entities.addAll(mainHitbox.getEntities());
    }

    /**
     * Updates the location of the dropdown components, refreshing options if expanded.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override
    public void updateLocation(double x, double y) {
        this.lastX = x;
        this.lastY = y;
        mainDisplay.updateLocation(x, y);
        mainHitbox.updateLocation(x, y);

        if (expanded) {
            // If the board rotates while open, we need to refresh the option positions
            hideOptions();
            showOptions();
        }
    }

    /**
     * Triggers the hitbox click logic.
     *
     * @param player The player clicking the dropdown.
     */
    @Override public void onClick(Player player) { mainHitbox.onClick(player); }

    /** No hover logic directly on the main dropdown */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this dropdown and its currently visible options.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
