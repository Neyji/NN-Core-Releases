package net.neyjaneyji.nNCore.internal;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Manages all active GUIs and registered GUI components.
 * Handles entity clicks, gaze tracking (hovering), and player movement for GUI updates.
 */
public class GUIManager implements Listener {

    private final Map<UUID, NNCoreGUI> activeGUIs = new HashMap<>();
    private final Map<UUID, GUIComponent> registeredHitboxes = new HashMap<>();
    private final Plugin plugin;

    /**
     * Constructs a new GUIManager.
     * Starts the gaze tracking engine for hover and tooltip support.
     *
     * @param plugin The main plugin instance.
     */
    public GUIManager(Plugin plugin) {
        this.plugin = plugin;
        startGazeTracking(); // Start the hover/tooltip engine
    }

    /**
     * Registers a new GUI for a specific player.
     *
     * @param playerId The UUID of the player.
     * @param gui The NNCoreGUI instance to register.
     */
    public void registerGUI(UUID playerId, NNCoreGUI gui) {
        activeGUIs.put(playerId, gui);
    }

    /**
     * Unregisters and cleans up a GUI for a specific player.
     *
     * @param playerId The UUID of the player.
     */
    public void unregisterGUI(UUID playerId) {
        NNCoreGUI gui = activeGUIs.remove(playerId);
        if (gui != null) {
            gui.cleanup();
        }
    }

    /**
     * Gets a map of all currently active GUIs.
     *
     * @return A map of player UUIDs to their active NNCoreGUI instances.
     */
    public Map<UUID, NNCoreGUI> getActiveGUIs() {
        return activeGUIs;
    }

    /**
     * Registers a GUI component to an entity's hitbox for interaction handling.
     *
     * @param entity The entity representing the hitbox.
     * @param component The GUIComponent associated with the hitbox.
     */
    public void registerComponent(Entity entity, GUIComponent component) {
        registeredHitboxes.put(entity.getUniqueId(), component);
    }

    /**
     * Handles entity click events.
     * Prevents normal interactions if the clicked entity is a registered GUI component,
     * and triggers the component's onClick action.
     *
     * @param event The PlayerInteractEntityEvent.
     */
    @EventHandler
    public void onEntityClick(PlayerInteractEntityEvent event) {
        Entity clicked = event.getRightClicked();

        // If the player clicked one of our registered interaction hitboxes
        if (registeredHitboxes.containsKey(clicked.getUniqueId())) {
            event.setCancelled(true); // Prevent normal Minecraft interactions

            // Trigger the onClick action for that specific component
            GUIComponent component = registeredHitboxes.get(clicked.getUniqueId());
            component.onClick(event.getPlayer());
        }
    }

    /**
     * Starts a repeating task to track player gaze for hover events.
     * Fires a raycast from each player's eyes to detect if they are looking at a registered GUI component.
     * Triggers the onHover action for components based on the raycast result.
     */
    private void startGazeTracking() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                NNCoreGUI activeGui = activeGUIs.get(player.getUniqueId());
                if (activeGui == null) continue;

                // Fire a raycast from the player's eyes
                org.bukkit.util.RayTraceResult result = player.getWorld().rayTraceEntities(
                        player.getEyeLocation(),
                        player.getEyeLocation().getDirection(),
                        10.0, // 10 block range
                        entity -> registeredHitboxes.containsKey(entity.getUniqueId())
                );

                // Tell all components if they are being hovered or not
                for (Map.Entry<UUID, GUIComponent> entry : registeredHitboxes.entrySet()) {
                    boolean isHovering = (result != null && result.getHitEntity() != null
                            && result.getHitEntity().getUniqueId().equals(entry.getKey()));

                    entry.getValue().onHover(player, isHovering);
                }
            }
        }, 0L, 5L); // Runs every 5 ticks (4 times a second)
    }

    /**
     * Handles player movement events.
     * Updates the rotation of the player's active GUI based on their current yaw.
     *
     * @param event The PlayerMoveEvent.
     */
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        NNCoreGUI gui = activeGUIs.get(player.getUniqueId());

        // If the player has an active GUI, tell it to check if it needs to rotate
        if (gui != null) {
            gui.updateRotation(player.getLocation().getYaw());
        }
    }
}
