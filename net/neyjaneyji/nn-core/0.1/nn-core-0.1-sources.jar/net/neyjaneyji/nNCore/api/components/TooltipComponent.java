package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;

import java.util.ArrayList;
import java.util.List;

/**
 * A component designed to show contextual information when a user hovers over
 * or interacts with another component. It starts hidden by default.
 */
public class TooltipComponent implements GUIComponent {
    private final String text;
    private TextDisplay display;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;

    /**
     * Constructs a TooltipComponent.
     *
     * @param text The text to display inside the tooltip.
     */
    public TooltipComponent(String text) {
        this.text = text;
    }

    /**
     * Toggles the visibility of the tooltip text and background.
     *
     * @param visible True to show the tooltip, false to hide it.
     */
    public void setVisible(boolean visible) {
        if (display != null && display.isValid()) {
            // Set opacity to 255 (visible) or -1 (invisible)
            display.setTextOpacity(visible ? (byte) 255 : (byte) -1);
            // Hide the background too
            display.setDefaultBackground(visible);
        }
    }

    /**
     * Spawns a TextDisplay entity for the tooltip, positioned slightly forward
     * to render in front of other GUI elements. Hidden by default.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        this.display = (TextDisplay) parent.getOrigin().getWorld().spawnEntity(
                parent.getPixelLocation(x, y), org.bukkit.entity.EntityType.TEXT_DISPLAY);

        display.setText(text);
        display.setAlignment(TextDisplay.TextAlignment.CENTER);

        // Push tooltips forward so they render IN FRONT of everything else (+0.05f Z-axis)
        org.bukkit.util.Transformation trans = display.getTransformation();
        trans.getTranslation().set(0, 0, 0.05f);
        display.setTransformation(trans);

        setVisible(false); // Hidden by default
        entities.add(display);
    }

    /**
     * Updates the location of the tooltip.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) {
        if (display != null) display.teleport(parent.getPixelLocation(x, y));
    }

    /** No interaction handling directly on the tooltip */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the tooltip */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets the TextDisplay entity for this tooltip.
     *
     * @return A list containing the TextDisplay entity.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
