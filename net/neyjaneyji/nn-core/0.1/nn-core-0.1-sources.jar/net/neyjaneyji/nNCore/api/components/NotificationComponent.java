package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import java.util.ArrayList;
import java.util.List;

/**
 * A component that displays a temporary message to the user.
 * It automatically removes itself after a set duration (5 seconds).
 */
public class NotificationComponent implements GUIComponent {
    private final TextComponent display;
    private final List<Entity> entities = new ArrayList<>();
    private final Plugin plugin;

    /**
     * Constructs a NotificationComponent.
     *
     * @param plugin The main plugin instance for scheduling the cleanup task.
     * @param message The message to display.
     * @param colorCode A formatting string (e.g., color or icon) to prefix the message.
     */
    public NotificationComponent(Plugin plugin, String message, String colorCode) {
        this.plugin = plugin;
        this.display = new TextComponent(colorCode + " " + message + " ");
    }

    /**
     * Spawns the notification text and schedules a task to remove it after 5 seconds.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        display.spawn(parent, x, y);
        entities.addAll(display.getEntities());

        // Auto-cleanup after 5 seconds (100 ticks)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            entities.forEach(Entity::remove);
            entities.clear();
        }, 100L);
    }

    /**
     * Updates the location of the notification text.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) { display.updateLocation(x, y); }

    /** No interaction handling directly on the notification */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the notification */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this notification.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
