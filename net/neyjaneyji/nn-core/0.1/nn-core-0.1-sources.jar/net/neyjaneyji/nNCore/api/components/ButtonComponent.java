package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A generic button component that displays text and can be clicked.
 * Automatically adds hover styling.
 */
public class ButtonComponent implements GUIComponent {
    private final String originalText;
    private final TextComponent label;
    private final HitboxComponent hitbox;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a ButtonComponent.
     *
     * @param text The text to display on the button.
     * @param width The physical width of the button's interaction hitbox.
     * @param height The physical height of the button's interaction hitbox.
     * @param action The action to execute when the button is clicked.
     */
    public ButtonComponent(String text, float width, float height, Consumer<Player> action) {
        this.originalText = text;
        this.label = new TextComponent(text);
        this.hitbox = new HitboxComponent(width, height, action);

        // Delegate the hover logic to the hitbox
        this.hitbox.setHoverAction((player, isHovering) -> {
            this.label.setText(isHovering ? "§e> " + originalText + " <" : originalText);
        });
    }

    /**
     * Spawns the label and hitbox for this button.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        label.spawn(parent, x, y);
        hitbox.spawn(parent, x, y);
        entities.addAll(label.getEntities());
        entities.addAll(hitbox.getEntities());
    }

    /**
     * Updates the location of the button's label and hitbox.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override
    public void updateLocation(double x, double y) {
        label.updateLocation(x, y);
        hitbox.updateLocation(x, y);
    }

    /**
     * Handled directly by HitboxComponent.
     *
     * @param player The player interacting.
     */
    @Override
    public void onClick(Player player) {} // Now handled directly by Hitbox

    /**
     * Handled directly by HitboxComponent.
     *
     * @param player The player hovering.
     * @param isHovering Whether the player is looking at the button.
     */
    @Override
    public void onHover(Player player, boolean isHovering) {} // Now handled directly by Hitbox

    /**
     * Gets all entities associated with this button.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
