package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * A component that wraps a list of other GUI components and displays a limited number
 * of them at a time, providing up/down buttons to scroll through the list.
 */
public class ScrollComponent implements GUIComponent {
    private final List<GUIComponent> allItems;
    private final int visibleSize;
    private int scrollIndex = 0;

    private final ButtonComponent btnUp;
    private final ButtonComponent btnDown;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;
    private double lastX, lastY;

    /**
     * Constructs a ScrollComponent.
     *
     * @param items The full list of GUIComponents to make scrollable.
     * @param visibleSize The maximum number of items to display at one time.
     */
    public ScrollComponent(List<GUIComponent> items, int visibleSize) {
        this.allItems = items;
        this.visibleSize = visibleSize;

        this.btnUp = new ButtonComponent("§b▲", 0.2f, 0.2f, p -> scroll(-1));
        this.btnDown = new ButtonComponent("§b▼", 0.2f, 0.2f, p -> scroll(1));
    }

    /**
     * Attempts to scroll the list by a given amount.
     *
     * @param amount The number of items to scroll by (negative for up, positive for down).
     */
    private void scroll(int amount) {
        int nextIndex = scrollIndex + amount;
        // Make sure we don't scroll out of bounds
        if (nextIndex >= 0 && nextIndex <= allItems.size() - visibleSize) {
            clearVisibleItems(); // Erase old items
            this.scrollIndex = nextIndex;
            spawnVisibleItems(); // Spawn the new items
        }
    }

    /**
     * Clears and removes the physical entities of currently visible items.
     */
    private void clearVisibleItems() {
        // Destroy the entities of the currently visible items
        for (int i = scrollIndex; i < scrollIndex + visibleSize; i++) {
            if (i >= allItems.size()) break;
            GUIComponent item = allItems.get(i);
            item.getEntities().forEach(e -> {
                if (e.isValid()) e.remove();
            });
            item.getEntities().clear();
        }
        // Reset our tracking list so it only contains the arrows
        entities.clear();
        entities.addAll(btnUp.getEntities());
        entities.addAll(btnDown.getEntities());
    }

    /**
     * Spawns the items currently determined to be visible based on the scroll index.
     */
    private void spawnVisibleItems() {
        double currentY = lastY;
        for (int i = scrollIndex; i < scrollIndex + visibleSize; i++) {
            if (i >= allItems.size()) break;
            GUIComponent item = allItems.get(i);
            item.spawn(parent, lastX, currentY); // Spawn new ones
            entities.addAll(item.getEntities()); // Add to tracking
            currentY += 8;
        }
    }

    /**
     * Spawns the scroll arrows and the initially visible items.
     *
     * @param parent The parent GUI.
     * @param x The base X coordinate.
     * @param y The starting Y coordinate.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        this.lastX = x;
        this.lastY = y;

        // Spawn arrows exactly once
        btnUp.spawn(parent, lastX + 30, lastY);
        btnDown.spawn(parent, lastX + 30, lastY + (visibleSize * 8));
        entities.addAll(btnUp.getEntities());
        entities.addAll(btnDown.getEntities());

        spawnVisibleItems();
    }

    /**
     * Updates the location of the scroll arrows and visible items.
     *
     * @param x The new base X coordinate.
     * @param y The new starting Y coordinate.
     */
    @Override
    public void updateLocation(double x, double y) {
        this.lastX = x;
        this.lastY = y;

        // Just move the arrows, don't respawn them!
        btnUp.updateLocation(lastX + 30, lastY);
        btnDown.updateLocation(lastX + 30, lastY + (visibleSize * 8));

        // Just move the visible items, don't respawn them!
        double currentY = lastY;
        for (int i = scrollIndex; i < scrollIndex + visibleSize; i++) {
            if (i >= allItems.size()) break;
            allItems.get(i).updateLocation(lastX, currentY);
            currentY += 8;
        }
    }

    /** Interaction handling is done by sub-components */
    @Override public void onClick(Player player) {}

    /** Hover handling is done by sub-components */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities currently making up this scroll component, including visible items and arrows.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
