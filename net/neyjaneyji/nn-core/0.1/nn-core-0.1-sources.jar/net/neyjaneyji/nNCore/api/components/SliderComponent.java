package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * A slider component that allows users to adjust a continuous value between 0.0 and 1.0.
 */
public class SliderComponent implements GUIComponent {
    private float value; // 0.0 to 1.0
    private final TextComponent track;
    private final HitboxComponent hitbox;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a SliderComponent.
     *
     * @param initialValue The starting value of the slider, between 0.0 and 1.0.
     * @param onChange A callback function executed when the slider is clicked. Provides the new value.
     */
    public SliderComponent(float initialValue, BiConsumer<Player, Float> onChange) {
        this.value = initialValue;
        this.track = new TextComponent(renderTrack());
        // Clicking this slider simple increments it by 0.1 for now
        // In the future, you can calculate the exact click position on the hitbox!
        this.hitbox = new HitboxComponent(1.0f, 0.2f, p -> {
            this.value = (value >= 1.0f) ? 0 : value + 0.1f;
            this.track.setText(renderTrack());
            onChange.accept(p, value);
        });
    }

    /**
     * Renders the text-based track for the slider, showing the filled and empty portions.
     *
     * @return The formatted string representing the slider track.
     */
    private String renderTrack() {
        int bars = 10;
        int progress = (int) (value * bars);
        return "§7[" + "§f|".repeat(progress) + "§8.".repeat(bars - progress) + "§7]";
    }

    /**
     * Spawns the slider track display and its interaction hitbox.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        track.spawn(parent, x, y);
        hitbox.spawn(parent, x, y);
        entities.addAll(track.getEntities());
        entities.addAll(hitbox.getEntities());
    }

    /**
     * Updates the location of the slider components.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) {
        track.updateLocation(x, y);
        hitbox.updateLocation(x, y);
    }

    /**
     * Triggers the hitbox click logic, advancing the slider value.
     *
     * @param player The player clicking the slider.
     */
    @Override public void onClick(Player player) { hitbox.onClick(player); }

    /** No hover logic directly on the slider */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this slider.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
