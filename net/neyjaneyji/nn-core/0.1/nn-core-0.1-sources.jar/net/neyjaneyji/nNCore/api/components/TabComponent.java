package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A component that displays a horizontal row of buttons acting as tabs.
 * Allows switching between different views or pages within a GUI.
 */
public class TabComponent implements GUIComponent {
    private final List<ButtonComponent> tabs = new ArrayList<>();
    private final List<Entity> entities = new ArrayList<>();
    private int activeIndex = 0;
    private final Consumer<Integer> onTabSwitch;

    /**
     * Constructs a TabComponent.
     *
     * @param labels A list of strings for the tab labels.
     * @param onTabSwitch A callback function executed when a tab is clicked. Provides the index of the clicked tab.
     */
    public TabComponent(List<String> labels, Consumer<Integer> onTabSwitch) {
        this.onTabSwitch = onTabSwitch;
        for (int i = 0; i < labels.size(); i++) {
            int index = i;
            // Create a button for each tab label
            tabs.add(new ButtonComponent(labels.get(i), 0.6f, 0.3f, p -> {
                this.activeIndex = index;
                onTabSwitch.accept(index);
                // In a real app, you'd refresh the visuals here
            }));
        }
    }

    /**
     * Spawns the tab buttons horizontally spaced out.
     *
     * @param parent The parent GUI.
     * @param x The starting X coordinate.
     * @param y The Y coordinate.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        double currentX = x;
        for (ButtonComponent btn : tabs) {
            btn.spawn(parent, currentX, y);
            entities.addAll(btn.getEntities());
            currentX += 25; // Space tabs out by 25 pixels
        }
    }

    /**
     * Updates the location of the tab buttons.
     *
     * @param x The new starting X coordinate.
     * @param y The new Y coordinate.
     */
    @Override
    public void updateLocation(double x, double y) {
        double currentX = x;
        for (ButtonComponent btn : tabs) {
            btn.updateLocation(currentX, y);
            currentX += 25;
        }
    }

    /** Interaction handling is done by the individual buttons */
    @Override public void onClick(Player player) {
        // Managed by individual buttons
    }

    /** Hover handling is done by the individual buttons */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with these tabs.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
