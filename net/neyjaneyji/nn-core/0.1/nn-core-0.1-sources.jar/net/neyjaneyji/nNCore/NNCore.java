package net.neyjaneyji.nNCore;

import net.neyjaneyji.nNCore.api.examples.ExampleGUI;
import net.neyjaneyji.nNCore.internal.GUIManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * The main plugin class for nNCore.
 * This class handles the initialization and cleanup of the plugin,
 * as well as registering the GUIManager and handling test commands.
 */
public class NNCore extends JavaPlugin {

    private static GUIManager guiManager;

    /**
     * Called when the plugin is enabled.
     * Initializes the GUIManager and registers its event handlers.
     */
    @Override
    public void onEnable() {
        guiManager = new GUIManager(this);
        getServer().getPluginManager().registerEvents(guiManager, this);
        getLogger().info("nNCore API enabled!");
    }

    /**
     * Called when the plugin is disabled.
     * Cleans up all active GUIs to prevent phantom entities on server restart.
     */
    @Override
    public void onDisable() {
        if (guiManager != null) {
            guiManager.getActiveGUIs().values().forEach(gui -> gui.cleanup());
            guiManager.getActiveGUIs().clear();
        }
        getLogger().info("nNCore API disabled and cleaned up!");
    }

    /**
     * Gets the active instance of the GUIManager.
     *
     * @return The GUIManager instance.
     */
    public static GUIManager getGuiManager() {
        return guiManager;
    }

    /**
     * Handles commands executed by a player or the console.
     *
     * @param sender The sender of the command.
     * @param cmd The command that was executed.
     * @param label The alias of the command used.
     * @param args The arguments passed to the command.
     * @return true if the command was handled successfully, false otherwise.
     */
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (sender instanceof Player player && label.equalsIgnoreCase("nntest")) {
            ExampleGUI gui = new ExampleGUI(player.getUniqueId(), player.getLocation());
            NNCore.getGuiManager().registerGUI(player.getUniqueId(), gui);
            player.sendMessage("§aSpawning nNCore Example Dashboard...");
            return true;
        }
        return false;
    }
}
