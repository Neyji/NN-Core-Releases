package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Color;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.util.Transformation;

import java.util.ArrayList;
import java.util.List;

/**
 * A background frame component used to provide a solid or translucent backing
 * to a group of components or an entire GUI.
 */
public class FrameComponent implements GUIComponent {
    private final Color bgColor;
    private final double widthInBlocks;
    private final double heightInBlocks;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;

    /**
     * Constructs a FrameComponent defined purely by Minecraft pixels.
     *
     * @param bgColor The background color of the frame.
     * @param widthPixels The width of the frame in pixels.
     * @param heightPixels The height of the frame in pixels.
     */
    public FrameComponent(Color bgColor, int widthPixels, int heightPixels) {
        this.bgColor = bgColor;
        this.widthInBlocks = widthPixels / 16.0;
        this.heightInBlocks = heightPixels / 16.0;
    }

    /**
     * Spawns a TextDisplay entity configured to act as a scaled background frame.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        org.bukkit.entity.TextDisplay background = (org.bukkit.entity.TextDisplay) parent.getOrigin().getWorld().spawnEntity(
                parent.getPixelLocation(x, y), org.bukkit.entity.EntityType.TEXT_DISPLAY);

        background.setText("test");
        background.setTextOpacity((byte) 0);
        background.setBackgroundColor(bgColor);
        background.setDefaultBackground(false);
        background.setLineWidth(200);
        background.setAlignment(org.bukkit.entity.TextDisplay.TextAlignment.CENTER);

        float scaleX = (float) (widthInBlocks / 0.525);
        float scaleY = (float) (heightInBlocks / 0.25);

        org.bukkit.util.Transformation trans = background.getTransformation();
        trans.getScale().set(scaleX, scaleY, 1.0f);

        trans.getTranslation().set(0.15f, 0.0f, -0.05f);

        background.setTransformation(trans);

        entities.add(background);
    }

    /**
     * Updates the location of the background frame.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) {
        if (!entities.isEmpty()) entities.get(0).teleport(parent.getPixelLocation(x, y));
    }

    /** No interaction handling directly on the frame */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the frame */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets the background frame entity.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
