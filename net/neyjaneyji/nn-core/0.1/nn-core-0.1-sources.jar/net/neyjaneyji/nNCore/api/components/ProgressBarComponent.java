package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Color;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * A component that visually represents a progress bar using a text display with colored block characters.
 */
public class ProgressBarComponent implements GUIComponent {
    private float progress; // 0.0 to 1.0
    private final Color color;
    private final TextComponent display;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a ProgressBarComponent.
     *
     * @param initialProgress The initial progress value, between 0.0 and 1.0.
     * @param color The color of the filled portion of the progress bar.
     */
    public ProgressBarComponent(float initialProgress, Color color) {
        this.progress = initialProgress;
        this.color = color;
        this.display = new TextComponent(renderBar());
    }

    /**
     * Renders the progress bar string using block characters and hex color codes.
     *
     * @return The formatted string representing the progress bar.
     */
    private String renderBar() {
        int width = 20;
        int filled = (int) (progress * width);

        // Convert the Bukkit Color into a Hex String so the TextDisplay can read it
        String hex = String.format("#%06x", color.asRGB() & 0xFFFFFF);
        String colorCode = net.md_5.bungee.api.ChatColor.of(hex).toString();

        return colorCode + "█".repeat(filled) + "§8" + "█".repeat(width - filled);
    }

    /**
     * Updates the progress value and visually refreshes the bar.
     *
     * @param progress The new progress value, between 0.0 and 1.0. Clamped if outside bounds.
     */
    public void setProgress(float progress) {
        this.progress = Math.max(0, Math.min(1, progress));
        this.display.setText(renderBar());
    }

    /**
     * Spawns the underlying text component representing the progress bar.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        display.spawn(parent, x, y);
        entities.addAll(display.getEntities());
    }

    /**
     * Updates the location of the underlying text component.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) { display.updateLocation(x, y); }

    /** No interaction handling directly on the progress bar */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the progress bar */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this progress bar.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
