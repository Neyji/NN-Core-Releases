package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;

import java.util.ArrayList;
import java.util.List;

/**
 * A fundamental component that displays text using a Minecraft TextDisplay entity.
 * It supports dynamic text updates and customizable text alignment.
 */
public class TextComponent implements GUIComponent {
    private String text;
    private final TextDisplay.TextAlignment alignment;
    private TextDisplay display;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;

    /**
     * Constructs a TextComponent with center alignment by default.
     *
     * @param text The initial text to display.
     */
    public TextComponent(String text) {
        this.text = text;
        this.alignment = TextDisplay.TextAlignment.CENTER;
    }

    /**
     * Constructs a TextComponent with a specified text alignment.
     *
     * @param text The initial text to display.
     * @param alignment The TextAlignment to use (e.g., LEFT, CENTER, RIGHT).
     */
    public TextComponent(String text, TextDisplay.TextAlignment alignment) {
        this.text = text;
        this.alignment = alignment;
    }

    /**
     * Updates the text displayed by this component.
     * Changes are reflected immediately in the world if the entity is valid.
     *
     * @param text The new text string.
     */
    public void setText(String text) {
        this.text = text;
        if (display != null && display.isValid()) {
            display.setText(text);
        }
    }

    /**
     * Gets the current text stored in this component.
     *
     * @return The current text string.
     */
    public String getText() {
        return this.text;
    }

    /**
     * Spawns a TextDisplay entity, applying alignment and clearing the background.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        this.display = (TextDisplay) parent.getOrigin().getWorld().spawnEntity(
                parent.getPixelLocation(x, y), org.bukkit.entity.EntityType.TEXT_DISPLAY);

        display.setText(text);

        // THE FIX: Use the chosen alignment!
        display.setAlignment(this.alignment);

        display.setDefaultBackground(false);
        display.setBackgroundColor(org.bukkit.Color.fromARGB(0, 0, 0, 0));

        entities.add(display);
    }

    /**
     * Updates the location of the TextDisplay entity.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override
    public void updateLocation(double x, double y) {
        if (display != null && display.isValid()) {
            display.teleport(parent.getPixelLocation(x, y));
        }
    }

    /** No interaction handling directly on the text component */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the text component */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets the TextDisplay entity for this component.
     *
     * @return A list containing the TextDisplay entity.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
