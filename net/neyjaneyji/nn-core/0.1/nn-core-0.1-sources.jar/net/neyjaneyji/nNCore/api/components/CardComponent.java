package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Color;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import java.util.ArrayList;
import java.util.List;

/**
 * A component that displays a formatted "card" with a title and a body text.
 */
public class CardComponent implements GUIComponent {
    private final String title;
    private final String body;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;

    /**
     * Constructs a CardComponent.
     *
     * @param title The title text of the card.
     * @param body The body text of the card.
     */
    public CardComponent(String title, String body) {
        this.title = "§l" + title;
        this.body = "§7" + body;
    }

    /**
     * Spawns the card background, title, and body text.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        // The background "Plate" of the card
        TextComponent background = new TextComponent("");
        background.spawn(parent, x, y);

        background.getEntities().forEach(e -> {
            if (e instanceof TextDisplay td) {
                td.setBackgroundColor(Color.fromARGB(80, 255, 255, 255)); // Light translucent white
                td.setLineWidth(80); // Define card width
            }
        });

        TextComponent titleText = new TextComponent(title);
        titleText.spawn(parent, x, y - 8);

        TextComponent bodyText = new TextComponent(body);
        bodyText.spawn(parent, x, y + 8);

        entities.addAll(background.getEntities());
        entities.addAll(titleText.getEntities());
        entities.addAll(bodyText.getEntities());
    }

    /**
     * Updates the location of the card components.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) {
        // In a real implementation, you'd iterate and teleport all sub-components
    }

    /** No interaction handling directly on the card */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the card */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this card.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
