package net.neyjaneyji.nNCore.api.examples;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import net.neyjaneyji.nNCore.api.components.*;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.bukkit.Bukkit.getPlayer;

/**
 * An example implementation of an NNCoreGUI, demonstrating how to use
 * various GUI components, tabs, pagination, and interactions.
 */
public class ExampleGUI extends NNCoreGUI {

    // --- GUI STATE VARIABLES (The "Working Function" memory) ---
    private int currentTab = 0; // 0: Settings, 1: Profile, 2: Admin
    private int currentPage = 0;

    // Mock Settings Data
    private boolean isSprintToggled = true;
    private boolean showParticles = false;
    private int renderDistance = 8;
    private float musicVolume = 0.5f;
    private String selectedDifficulty = "Normal";

    /**
     * Constructs a new ExampleGUI.
     *
     * @param ownerId The UUID of the player who will view and interact with the GUI.
     * @param origin The starting location of the GUI.
     */
    public ExampleGUI(UUID ownerId, Location origin) {
        super(ownerId, origin);
        refreshLayout();
    }

    /**
     * Rebuilds the layout of the GUI, clearing existing components and spawning new ones
     * based on the current state (e.g., active tab and page).
     */
    @Override
    public void refreshLayout() {
        cleanup();

        // 1. The 96x80 Pixel Frame (Bottom-Center at 0,0)
        addComponent(new FrameComponent(org.bukkit.Color.fromARGB(240, 30, 30, 35), 96, 80), 0, 0);

        // 2. Global Header (Y = 70)
        String tabName = currentTab == 0 ? "Settings" : (currentTab == 1 ? "Profile" : "Admin");
        addComponent(new BreadcrumbComponent("Menu", tabName), -30, 70);

        addComponent(new ButtonComponent("§c✖ Close", 0.6f, 0.2f, p -> {
            net.neyjaneyji.nNCore.NNCore.getGuiManager().unregisterGUI(p.getUniqueId());
            p.sendMessage("§cClosed Dashboard.");
        }), 30, 70);

        // 3. Navigation Bar (Y = 60)
        NavBarComponent nav = new NavBarComponent();
        nav.addLink(currentTab == 0 ? "§b[Settings]" : "§7Settings", p -> switchTab(0));
        nav.addLink(currentTab == 1 ? "§b[Profile]" : "§7Profile", p -> switchTab(1));
        nav.addLink(currentTab == 2 ? "§b[Admin]" : "§7Admin", p -> switchTab(2));
        addComponent(nav, 0, 60);

        // 4. Render Active Tab
        if (currentTab == 0) renderSettingsTab();
        else if (currentTab == 1) renderProfileTab();
        else if (currentTab == 2) renderAdminTab();
    }

    /**
     * Switches the active tab and resets pagination before refreshing the layout.
     *
     * @param tab The index of the tab to switch to (0: Settings, 1: Profile, 2: Admin).
     */
    private void switchTab(int tab) {
        this.currentTab = tab;
        this.currentPage = 0; // Reset pagination on tab switch
        refreshLayout();
    }

    // ==========================================
    // TAB 1: SETTINGS (Interactive Inputs)
    // ==========================================

    /**
     * Renders the Settings tab, containing various interactive inputs like toggles,
     * checkboxes, steppers, and sliders. Includes pagination logic for displaying items.
     */
    private void renderSettingsTab() {
        List<GUIComponent[]> allRows = new ArrayList<>();

        // Build the dynamic rows linking to our state variables
        allRows.add(new GUIComponent[]{
                new TextComponent("Auto-Sprint:", TextDisplay.TextAlignment.LEFT),
                new ToggleComponent(isSprintToggled, (p, state) -> this.isSprintToggled = state)
        });
        allRows.add(new GUIComponent[]{
                new TextComponent("Particles:", TextDisplay.TextAlignment.LEFT),
                new CheckboxComponent(showParticles, (p, state) -> this.showParticles = state)
        });
        allRows.add(new GUIComponent[]{
                new TextComponent("Render Dist:", TextDisplay.TextAlignment.LEFT),
                new StepperComponent(renderDistance, 2, 16, (p, val) -> this.renderDistance = val)
        });
        allRows.add(new GUIComponent[]{
                new TextComponent("Music Vol:", TextDisplay.TextAlignment.LEFT),
                new SliderComponent(musicVolume, (p, val) -> this.musicVolume = val)
        });
        allRows.add(new GUIComponent[]{
                new TextComponent("Difficulty:", TextDisplay.TextAlignment.LEFT),
                new RadioButtonComponent(Arrays.asList("Peaceful", "Normal", "Hard"), index -> {
                    this.selectedDifficulty = index == 0 ? "Peaceful" : (index == 1 ? "Normal" : "Hard");
                })
        });

        // Pagination Logic
        int itemsPerPage = 4;
        int startIndex = currentPage * itemsPerPage;
        int endIndex = Math.min(startIndex + itemsPerPage, allRows.size());

        int currentY = 45; // Start below NavBar
        for (int i = startIndex; i < endIndex; i++) {
            addComponent(allRows.get(i)[0], -30, currentY); // Label Left
            addComponent(allRows.get(i)[1], 15, currentY);  // Input Right
            currentY -= 10;
        }

        // Save Button (Spawns Notification)
        addComponent(new ButtonComponent("§a✔ Save Changes", 0.8f, 0.2f, p -> {
            addComponent(new NotificationComponent(net.neyjaneyji.nNCore.NNCore.getPlugin(net.neyjaneyji.nNCore.NNCore.class),
                    "Settings Saved!", "§a✔"), 0, 40);
        }), 0, currentY - 5);

        // Pagination Controls
        if (currentPage > 0) addComponent(new ButtonComponent("§b<", 0.6f, 0.2f, p -> { currentPage--; refreshLayout(); }), -30, 5);
        if (endIndex < allRows.size()) addComponent(new ButtonComponent("§b>", 0.6f, 0.2f, p -> { currentPage++; refreshLayout(); }), 30, 5);
    }

    // ==========================================
    // TAB 2: PROFILE (Display & Visuals)
    // ==========================================

    /**
     * Renders the Profile tab, demonstrating static displays, dropdowns,
     * item displays, and progress bars.
     */
    private void renderProfileTab() {
        // Dropdown
        addComponent(new DropdownComponent(Arrays.asList("Global Stats", "Weekly Stats"), "Select View", selection -> {
            System.out.println("Viewing: " + selection);
        }), -15, 45);

        // Card displaying information
        addComponent(new CardComponent("Player Info", "Rank: MVP+\nGuild: None"), -15, 25);

        // Render an actual 3D Item inside the GUI!
        addComponent(new ItemComponent(new ItemStack(Material.DIAMOND_SWORD), 0.4f), 20, 35);

        // Progress Bar (Mock XP bar)
        addComponent(new TextComponent("Level 42", TextDisplay.TextAlignment.CENTER), 20, 20);
        addComponent(new ProgressBarComponent(0.75f, Color.LIME), 0, 12);
    }

    // ==========================================
    // TAB 3: ADMIN ACTIONS (Lists & Modals)
    // ==========================================

    /**
     * Renders the Admin tab, showcasing search bars, scrollable lists,
     * modals (confirmation dialogs), and error messages.
     */
    private void renderAdminTab() {
        // Mock Search Bar (Triggers a chat prompt, and reacts when a search is fired)
        addComponent(new SearchBarComponent("Search player...", query -> {
            // Fetch the player who owns this GUI
            Player p = getPlayer(this.ownerId);
            if (p != null) {
                p.sendMessage("§b[Dashboard] §7Searching database for: §f" + query);
            }

            // Dynamically spawn a notification ON THE BOARD to prove it worked!
            addComponent(new NotificationComponent(net.neyjaneyji.nNCore.NNCore.getPlugin(net.neyjaneyji.nNCore.NNCore.class),
                    "Found: " + query, "§a✔"), 0, 30);
        }), 0, 45);

        // Scrollable List of "Players"
        List<GUIComponent> playerList = new ArrayList<>();
        for (int i = 1; i <= 8; i++) {
            final int pid = i;
            playerList.add(new ButtonComponent("§7Player_" + pid, 0.8f, 0.2f, p -> p.sendMessage("Selected Player " + pid)));
        }
        addComponent(new ScrollComponent(playerList, 3), -15, 25); // Show 3 at a time

        // Danger Button -> Triggers Modal
        addComponent(new ButtonComponent("§cBan All", 0.8f, 0.2f, p -> {
            addComponent(new ModalComponent("Are you sure you want to ban everyone?"), 0, 30);
        }), 20, 30);

        // Error Button -> Triggers ErrorMessage
        addComponent(new ButtonComponent("§eCrash Server", 0.8f, 0.2f, p -> {
            addComponent(new ErrorMessageComponent("Access Denied: Missing Permissions"), 0, 10);
        }), 20, 15);
    }
}
