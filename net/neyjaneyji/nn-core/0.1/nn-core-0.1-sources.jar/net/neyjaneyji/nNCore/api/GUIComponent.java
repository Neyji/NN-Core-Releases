package net.neyjaneyji.nNCore.api;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.List;

/**
 * Interface defining the base contract for all GUI components in nNCore.
 * Components handle rendering, logic, and user interaction within an NNCoreGUI.
 */
public interface GUIComponent {

    /**
     * Spawns the component on the board.
     * x and y are the "pixel" coordinates, where typically X is 0 to 1000 and Y is 0 to 1400.
     * 
     * @param parent The parent NNCoreGUI instance.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    void spawn(NNCoreGUI parent, double x, double y);

    /**
     * Updates the physical location of the component entities in the world.
     * Called when the parent board snaps or rotates to a new yaw.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    void updateLocation(double x, double y);

    /**
     * Triggered when a player interacts with (clicks on) the component's hitbox entity.
     *
     * @param player The player who clicked the component.
     */
    void onClick(Player player);

    /**
     * Triggered continually by the gaze tracking system.
     * Useful for hover effects, tooltips, or highlighting.
     *
     * @param player The player looking at the component.
     * @param isHovering True if the player is currently looking at the component's hitbox.
     */
    void onHover(Player player, boolean isHovering);

    /**
     * Gets a list of all physical entities making up this component (e.g., text displays, interaction entities).
     * Used mainly for cleanup and tracking.
     *
     * @return A list of the component's Bukkit entities.
     */
    List<Entity> getEntities();
}
