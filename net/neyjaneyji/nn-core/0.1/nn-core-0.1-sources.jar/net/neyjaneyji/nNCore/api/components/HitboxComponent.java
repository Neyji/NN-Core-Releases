package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.NNCore;
import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * A purely invisible component that handles click and hover interactions
 * by spawning a Minecraft Interaction entity.
 */
public class HitboxComponent implements GUIComponent {

    private final float width;
    private final float height;
    private Interaction interaction;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;

    private final Consumer<Player> clickAction;
    private BiConsumer<Player, Boolean> hoverAction;

    /**
     * Constructs a HitboxComponent.
     *
     * @param width The physical width of the interaction entity in blocks.
     * @param height The physical height of the interaction entity in blocks.
     * @param clickAction A callback function executed when the hitbox is clicked.
     */
    public HitboxComponent(float width, float height, Consumer<Player> clickAction) {
        this.width = width;
        this.height = height;
        this.clickAction = clickAction;
    }

    /**
     * Sets an action to be performed when a player looks at (hovers over) or looks away from the hitbox.
     *
     * @param hoverAction A callback function taking the player and a boolean representing hover state.
     */
    public void setHoverAction(BiConsumer<Player, Boolean> hoverAction) {
        this.hoverAction = hoverAction;
    }

    /**
     * Spawns an Interaction entity at the specified coordinates and registers it with the GUIManager.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        this.interaction = (Interaction) parent.getOrigin().getWorld().spawnEntity(
                parent.getPixelLocation(x, y), EntityType.INTERACTION);

        interaction.setInteractionWidth(width);
        interaction.setInteractionHeight(height);
        entities.add(interaction);

        NNCore.getGuiManager().registerComponent(interaction, this);
    }

    /**
     * Updates the location of the interaction entity.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override
    public void updateLocation(double x, double y) {
        if (interaction != null) interaction.teleport(parent.getPixelLocation(x, y));
    }

    /**
     * Triggers the defined click action.
     *
     * @param player The player who clicked the hitbox.
     */
    @Override
    public void onClick(Player player) {
        if (clickAction != null) clickAction.accept(player);
    }

    /**
     * Triggers the defined hover action.
     *
     * @param player The player whose gaze was updated.
     * @param isHovering True if the player is looking at the hitbox, false otherwise.
     */
    @Override
    public void onHover(Player player, boolean isHovering) {
        if (hoverAction != null) hoverAction.accept(player, isHovering);
    }

    /**
     * Gets the interaction entity for this hitbox.
     *
     * @return A list containing the Interaction entity.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
