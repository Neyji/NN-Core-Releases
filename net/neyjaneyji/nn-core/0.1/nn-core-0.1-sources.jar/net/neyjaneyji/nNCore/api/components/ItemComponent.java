package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Transformation;

import java.util.ArrayList;
import java.util.List;

/**
 * A component that visually displays a 3D Minecraft item inside the GUI.
 */
public class ItemComponent implements GUIComponent {
    private final ItemStack item;
    private final float scale;
    private final List<Entity> entities = new ArrayList<>();
    private NNCoreGUI parent;

    /**
     * Constructs an ItemComponent.
     *
     * @param item The ItemStack to display.
     * @param scale The visual scale of the item in the GUI.
     */
    public ItemComponent(ItemStack item, float scale) {
        this.item = item;
        this.scale = scale;
    }

    /**
     * Spawns an ItemDisplay entity to represent the ItemStack visually.
     * Appends a small forward translation to prevent clipping with background frames.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        ItemDisplay display = (ItemDisplay) parent.getOrigin().getWorld().spawnEntity(
                parent.getPixelLocation(x, y), org.bukkit.entity.EntityType.ITEM_DISPLAY);

        display.setItemStack(item);

        // Scale the item up or down
        Transformation trans = display.getTransformation();
        trans.getScale().set(scale, scale, scale);
        // Push items slightly forward so they don't clip into frames
        trans.getTranslation().set(0, 0, 0.05f);
        display.setTransformation(trans);

        entities.add(display);
    }

    /**
     * Updates the location of the ItemDisplay entity.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) {
        if (!entities.isEmpty()) entities.get(0).teleport(parent.getPixelLocation(x, y));
    }

    /** No interaction handling directly on the item component */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the item component */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets the ItemDisplay entity for this component.
     *
     * @return A list containing the ItemDisplay entity.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
