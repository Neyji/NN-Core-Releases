package net.neyjaneyji.nNCore.api;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Abstract base class representing a Graphical User Interface in nNCore.
 * Provides functionality for spawning, rotating, and managing a collection of GUIComponents.
 */
public abstract class NNCoreGUI {

    protected final Location origin;
    protected final UUID ownerId;
    protected final List<GUIComponent> components = new ArrayList<>();
    protected float currentBoardYaw;

    /**
     * Constructs a new NNCoreGUI for a specific player at a given origin location.
     * Snaps the initial yaw to 90-degree increments.
     *
     * @param ownerId The UUID of the player who owns this GUI.
     * @param origin The starting location of the GUI.
     */
    public NNCoreGUI(UUID ownerId, Location origin) {
        this.ownerId = ownerId;
        Location blockCenter = origin.getBlock().getLocation().add(0.5, 1.0, 0.5);
        blockCenter.setPitch(0);
        this.origin = blockCenter;
        this.currentBoardYaw = net.neyjaneyji.nNCore.utils.MathUtils.calculateSnappedYaw(origin.getYaw());
    }

    /**
     * Gets the origin location of the GUI.
     *
     * @return The Location representing the GUI's origin.
     */
    public Location getOrigin() {
        return this.origin;
    }

    /**
     * Core logic to update board rotation based on player movement.
     * Snaps the board to face the player if they turn more than 85 degrees away.
     *
     * @param playerYaw The current yaw of the player.
     */
    public void updateRotation(float playerYaw) {
        float diff = playerYaw - this.currentBoardYaw;
        while (diff <= -180.0f) diff += 360.0f;
        while (diff > 180.0f) diff -= 360.0f;

        // Snap if looking 85+ degrees away
        if (Math.abs(diff) >= 85.0f) {
            float newSnappedYaw = net.neyjaneyji.nNCore.utils.MathUtils.calculateSnappedYaw(playerYaw);
            if (newSnappedYaw != this.currentBoardYaw) {
                this.currentBoardYaw = newSnappedYaw;
                refreshLayout(); // Redraw the whole board in the new direction!
            }
        }
    }

    /**
     * Translates a pixel-based coordinate (x, y) into an actual Bukkit Location based
     * on the current snapped yaw and origin of the board.
     *
     * @param x The pixel X coordinate (left/right offset).
     * @param y The pixel Y coordinate (up/down offset).
     * @return The computed Location for the component in the world.
     */
    public Location getPixelLocation(double x, double y) {
        // True Minecraft Pixels -> Blocks
        double physicalX = x / 16.0;
        double physicalY = y / 16.0;

        Vector forward = net.neyjaneyji.nNCore.utils.MathUtils.getDirection(this.currentBoardYaw);

        // This vector points to the player's RIGHT when looking at the board
        Vector right = forward.clone().getCrossProduct(new Vector(0, 1, 0)).normalize();

        // Base center of the board (2 blocks in front of player, at floor level)
        Location loc = origin.clone().add(forward.clone().multiply(2.0));

        // Add true pixel offsets!
        loc.add(right.multiply(physicalX)); // Positive X = Right, Negative X = Left
        loc.add(0, physicalY, 0);           // Positive Y = Up

        loc.setYaw(this.currentBoardYaw + 180.0f);
        loc.setPitch(0);

        return loc;
    }

    /**
     * Spawns a component onto the GUI and ensures it is only visible to the GUI's owner.
     *
     * @param component The GUIComponent to add to the board.
     * @param x The X pixel coordinate to spawn the component at.
     * @param y The Y pixel coordinate to spawn the component at.
     */
    public void addComponent(GUIComponent component, double x, double y) {
        component.spawn(this, x, y);
        components.add(component);

        // Make it only visible to the owner
        Player owner = org.bukkit.Bukkit.getPlayer(this.ownerId);

        for (Entity e : component.getEntities()) {

            // ONLY hide from everyone else.
            // DO NOT put the GUIManager.registerComponent() line here!
            for (Player online : org.bukkit.Bukkit.getOnlinePlayers()) {
                if (owner != null && !online.equals(owner)) {
                    online.hideEntity(net.neyjaneyji.nNCore.NNCore.getPlugin(net.neyjaneyji.nNCore.NNCore.class), e);
                }
            }
        }
    }

    /**
     * Forces all components to recalculate their locations, typically called after a rotation.
     * Implementing classes must define how the components are arranged and update their positions.
     */
    public abstract void refreshLayout();

    /**
     * Removes and cleans up all physical entities spawned by this GUI's components.
     * Clears the components list.
     */
    public void cleanup() {
        for (GUIComponent component : components) {
            for (Entity e : component.getEntities()) {
                if (e != null && e.isValid()) {
                    e.remove();
                }
            }
        }
        components.clear();
    }
}
