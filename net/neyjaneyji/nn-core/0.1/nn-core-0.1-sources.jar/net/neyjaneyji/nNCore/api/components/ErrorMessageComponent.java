package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple component that displays an error message formatted with red text and a warning icon.
 */
public class ErrorMessageComponent implements GUIComponent {
    private final TextComponent display;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs an ErrorMessageComponent.
     *
     * @param error The error message string to display.
     */
    public ErrorMessageComponent(String error) {
        this.display = new TextComponent("§c⚠ " + error);
    }

    /**
     * Spawns the error message text.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        display.spawn(parent, x, y);
        entities.addAll(display.getEntities());
    }

    /**
     * Updates the location of the error message text.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) { display.updateLocation(x, y); }

    /** No interaction handling directly on the error message */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the error message */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this error message.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
