package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;

import java.util.List;

/**
 * A component that displays a navigational breadcrumb trail (e.g. Menu > Settings).
 */
public class BreadcrumbComponent implements GUIComponent {
    private final TextComponent display;

    /**
     * Constructs a BreadcrumbComponent from a list of strings representing the path.
     *
     * @param path An array of strings representing the breadcrumb trail.
     */
    public BreadcrumbComponent(String... path) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.length; i++) {
            if (i == path.length - 1) {
                sb.append("§f").append(path[i]);
            } else {
                sb.append("§7").append(path[i]).append(" §8> ");
            }
        }
        // Explicitly align center (though can be changed to left if needed)
        this.display = new TextComponent(sb.toString(), TextDisplay.TextAlignment.CENTER);
    }

    /**
     * Spawns the underlying text component.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        display.spawn(parent, x, y);
    }

    /**
     * Updates the location of the underlying text component.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) { display.updateLocation(x, y); }

    /** No interaction handling directly on the breadcrumb */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the breadcrumb */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this breadcrumb.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return display.getEntities(); }
}
