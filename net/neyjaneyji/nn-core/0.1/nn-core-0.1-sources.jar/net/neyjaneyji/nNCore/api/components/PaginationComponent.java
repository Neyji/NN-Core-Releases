package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A component that provides pagination controls, including previous/next buttons
 * and a display of the current page.
 */
public class PaginationComponent implements GUIComponent {
    private int currentPage = 1;
    private final int maxPages;
    private final TextComponent pageText;
    private final ButtonComponent prev;
    private final ButtonComponent next;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a PaginationComponent.
     *
     * @param maxPages The total number of pages.
     * @param onPageChange A callback function executed when the page changes. Provides the new page number.
     */
    public PaginationComponent(int maxPages, Consumer<Integer> onPageChange) {
        this.maxPages = maxPages;
        this.pageText = new TextComponent("Page " + currentPage + "/" + maxPages);

        this.prev = new ButtonComponent("§7<<", 0.2f, 0.2f, p -> {
            if (currentPage > 1) { currentPage--; update(onPageChange, p); }
        });
        this.next = new ButtonComponent("§7>>", 0.2f, 0.2f, p -> {
            if (currentPage < maxPages) { currentPage++; update(onPageChange, p); }
        });
    }

    /**
     * Updates the page display text and triggers the callback function.
     *
     * @param callback The callback function.
     * @param p The player who changed the page.
     */
    private void update(Consumer<Integer> callback, Player p) {
        pageText.setText("Page " + currentPage + "/" + maxPages);
        callback.accept(currentPage);
    }

    /**
     * Spawns the pagination buttons and text display horizontally.
     *
     * @param parent The parent GUI.
     * @param x The central X coordinate for the component.
     * @param y The Y coordinate for the component.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        prev.spawn(parent, x - 100, y);
        pageText.spawn(parent, x, y);
        next.spawn(parent, x + 100, y);
        entities.addAll(prev.getEntities());
        entities.addAll(pageText.getEntities());
        entities.addAll(next.getEntities());
    }

    /** No movement logic implemented directly for the pagination container */
    @Override public void updateLocation(double x, double y) {}

    /** No interaction handling directly on the pagination container */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the pagination container */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this component, including buttons and text.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
