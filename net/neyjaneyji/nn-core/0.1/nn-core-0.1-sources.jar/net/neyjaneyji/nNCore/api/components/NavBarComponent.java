package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Color;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import java.util.ArrayList;
import java.util.List;

/**
 * A navigation bar component that displays a horizontal list of clickable links.
 */
public class NavBarComponent implements GUIComponent {
    private final List<ButtonComponent> navButtons = new ArrayList<>();
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Adds a navigational link (button) to the bar.
     *
     * @param label The text to display for the link.
     * @param action The action to perform when the link is clicked.
     */
    public void addLink(String label, org.bukkit.util.Consumer<Player> action) {
        navButtons.add(new ButtonComponent(label, 0.4f, 0.2f, action::accept));
    }

    /**
     * Spawns the navigation bar background and all its link buttons horizontally.
     *
     * @param parent The parent GUI.
     * @param x The central X coordinate of the navigation bar.
     * @param y The Y coordinate of the navigation bar.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        // Background Bar
        TextComponent bar = new TextComponent("");
        bar.spawn(parent, x, y); // Use provided x position
        bar.getEntities().forEach(e -> {
            if (e instanceof TextDisplay td) {
                td.setBackgroundColor(Color.fromARGB(255, 20, 20, 20)); // Solid dark bar
                td.setLineWidth(200); // Reasonable width for pixel scale
            }
        });
        entities.addAll(bar.getEntities());

        int totalButtons = navButtons.size();
        int spacing = 30; // Smaller spacing for pixel scale
        double startX = x - ((totalButtons - 1) * spacing / 2.0);

        double currentX = startX;
        for (ButtonComponent btn : navButtons) {
            btn.spawn(parent, currentX, y);
            entities.addAll(btn.getEntities());
            currentX += spacing;
        }
    }

    /** No movement logic implemented directly for the navbar container */
    @Override public void updateLocation(double x, double y) {}

    /** No interaction handling directly on the navbar container */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the navbar container */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this navigation bar, including background and buttons.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
