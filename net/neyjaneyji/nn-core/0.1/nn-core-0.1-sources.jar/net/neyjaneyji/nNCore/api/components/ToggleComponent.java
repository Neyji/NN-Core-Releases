package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * A toggle switch component that allows users to flip between an ON and OFF state.
 */
public class ToggleComponent implements GUIComponent {
    private boolean enabled;
    private final TextComponent display;
    private final HitboxComponent hitbox;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a ToggleComponent.
     *
     * @param initialState The starting state of the toggle (true = ON).
     * @param onToggle A callback function executed when the toggle is clicked. Provides the new boolean state.
     */
    public ToggleComponent(boolean initialState, BiConsumer<Player, Boolean> onToggle) {
        this.enabled = initialState;
        this.display = new TextComponent(enabled ? "§bON" : "§8OFF");
        this.hitbox = new HitboxComponent(0.4f, 0.3f, p -> {
            this.enabled = !this.enabled;
            this.display.setText(enabled ? "§bON" : "§8OFF");
            onToggle.accept(p, enabled);
        });
    }

    /**
     * Spawns the toggle display and its interaction hitbox.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        display.spawn(parent, x, y);
        hitbox.spawn(parent, x, y);
        entities.addAll(display.getEntities());
        entities.addAll(hitbox.getEntities());
    }

    /**
     * Updates the location of the toggle components.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override public void updateLocation(double x, double y) {
        display.updateLocation(x, y);
        hitbox.updateLocation(x, y);
    }

    /**
     * Triggers the hitbox click logic, flipping the toggle state.
     *
     * @param player The player clicking the toggle.
     */
    @Override public void onClick(Player player) { hitbox.onClick(player); }

    /** No hover logic directly on the toggle */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this toggle.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
