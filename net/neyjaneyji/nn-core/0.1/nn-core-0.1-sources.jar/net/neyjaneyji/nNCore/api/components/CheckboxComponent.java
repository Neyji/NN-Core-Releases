package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * A checkbox component that can be toggled on or off by clicking.
 */
public class CheckboxComponent implements GUIComponent {
    private boolean checked;
    private final TextComponent icon;
    private final HitboxComponent hitbox;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a CheckboxComponent.
     *
     * @param initialState The initial state of the checkbox (true = checked).
     * @param onToggle A callback function executed when the checkbox is toggled.
     */
    public CheckboxComponent(boolean initialState, BiConsumer<Player, Boolean> onToggle) {
        this.checked = initialState;
        this.icon = new TextComponent(checked ? "§a[✔]" : "§7[ ]");
        this.hitbox = new HitboxComponent(0.3f, 0.3f, p -> {
            this.checked = !this.checked;
            this.icon.setText(checked ? "§a[✔]" : "§7[ ]");
            onToggle.accept(p, checked);
        });
    }

    /**
     * Spawns the checkbox icon and its interaction hitbox.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        icon.spawn(parent, x, y);
        hitbox.spawn(parent, x, y);
        entities.addAll(icon.getEntities());
        entities.addAll(hitbox.getEntities());
    }

    /**
     * Updates the location of the checkbox components.
     *
     * @param x The new X coordinate on the GUI plane.
     * @param y The new Y coordinate on the GUI plane.
     */
    @Override
    public void updateLocation(double x, double y) {
        icon.updateLocation(x, y);
        hitbox.updateLocation(x, y);
    }

    /**
     * Triggers the hitbox click logic.
     *
     * @param player The player clicking the checkbox.
     */
    @Override public void onClick(Player player) { hitbox.onClick(player); }

    /** No hover logic directly on the checkbox */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this checkbox.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
