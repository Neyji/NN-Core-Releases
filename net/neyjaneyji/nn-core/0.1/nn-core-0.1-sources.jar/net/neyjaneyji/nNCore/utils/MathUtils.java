package net.neyjaneyji.nNCore.utils;

import org.bukkit.Location;
import org.bukkit.util.Vector;

/**
 * Utility class containing various mathematical functions, particularly
 * focused on rotations and vector calculations for GUI placement.
 */
public class MathUtils {

    /**
     * Snaps a yaw value to the nearest 90-degree increment (0, 90, 180, 270).
     * Useful for aligning GUIs perfectly to compass directions.
     *
     * @param playerYaw The raw yaw value from the player.
     * @return The snapped yaw value.
     */
    public static float calculateSnappedYaw(float playerYaw) {
        float snappedYaw = Math.round(playerYaw / 90.0f) * 90.0f;
        while (snappedYaw <= -180.0f) snappedYaw += 360.0f;
        while (snappedYaw > 180.0f) snappedYaw -= 360.0f;
        return snappedYaw;
    }

    /**
     * Gets a normalized forward vector based on a given yaw value (assuming pitch is 0).
     * Used to calculate the forward direction of a GUI based on its snapped yaw.
     *
     * @param yaw The yaw angle in degrees.
     * @return A normalized direction vector.
     */
    public static Vector getDirection(float yaw) {
        double radians = Math.toRadians(yaw);
        // Standard Minecraft direction calculation
        double x = -Math.sin(radians);
        double z = Math.cos(radians);
        return new Vector(x, 0, z).normalize();
    }

    /**
     * Calculates a 'Right' vector relative to a given forward direction.
     * Useful for moving components laterally left or right on the GUI board.
     *
     * @param forward The forward direction vector.
     * @return A normalized right direction vector.
     */
    public static Vector getRightVector(Vector forward) {
        return forward.clone().getCrossProduct(new Vector(0, 1, 0)).normalize();
    }

    /**
     * Checks if a player's eye direction is roughly pointing at a target location.
     * Used for gaze detection and hovering logic in the GUI.
     *
     * @param eyeLocation The player's eye location.
     * @param target The location of the entity or component.
     * @param threshold The sensitivity angle in radians (smaller is more precise).
     * @return true if the angle between the look direction and target vector is less than the threshold.
     */
    public static boolean isLookingAt(Location eyeLocation, Location target, double threshold) {
        Vector toTarget = target.toVector().subtract(eyeLocation.toVector()).normalize();
        Vector direction = eyeLocation.getDirection();
        return direction.angle(toTarget) < threshold;
    }
}
