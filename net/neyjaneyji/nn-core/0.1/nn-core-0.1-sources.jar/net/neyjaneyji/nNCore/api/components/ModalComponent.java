package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.Color;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import java.util.ArrayList;
import java.util.List;

/**
 * A modal dialog component that creates a darkened overlay and a centralized
 * alert box to draw the user's attention to a specific message.
 */
public class ModalComponent implements GUIComponent {
    private final String content;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a ModalComponent.
     *
     * @param content The message to display inside the modal dialog.
     */
    public ModalComponent(String content) {
        this.content = content;
    }

    /**
     * Spawns a darkened overlay background and a CardComponent as the dialog box.
     *
     * @param parent The parent GUI.
     * @param x The X coordinate on the GUI plane.
     * @param y The Y coordinate on the GUI plane.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        // Overlay (dim the whole board)
        TextComponent overlay = new TextComponent("");
        overlay.spawn(parent, x, y);
        overlay.getEntities().forEach(e -> {
            if (e instanceof TextDisplay td) {
                td.setBackgroundColor(Color.fromARGB(180, 0, 0, 0));
                td.setLineWidth(160);
                // Scaling this to cover height would require transformation math
            }
        });

        // The Modal Box
        CardComponent box = new CardComponent("Alert", content);
        box.spawn(parent, x, y);

        entities.addAll(overlay.getEntities());
        entities.addAll(box.getEntities());
    }

    /** No movement logic implemented directly for modals */
    @Override public void updateLocation(double x, double y) {}

    /** No interaction handling directly on the modal container */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the modal container */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this modal, including the overlay and the box.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
