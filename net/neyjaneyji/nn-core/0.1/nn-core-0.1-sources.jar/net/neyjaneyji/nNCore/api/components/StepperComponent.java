package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

/**
 * A component that allows users to increment or decrement an integer value
 * within a specified range using plus and minus buttons.
 */
public class StepperComponent implements GUIComponent {
    private int value;
    private final int min, max;
    private final TextComponent display;
    private final ButtonComponent btnMinus;
    private final ButtonComponent btnPlus;
    private final List<Entity> entities = new ArrayList<>();

    /**
     * Constructs a StepperComponent.
     *
     * @param initial The starting integer value.
     * @param min The minimum allowed value.
     * @param max The maximum allowed value.
     * @param onChange A callback function executed when the value changes. Provides the new value.
     */
    public StepperComponent(int initial, int min, int max, BiConsumer<Player, Integer> onChange) {
        this.value = initial;
        this.min = min;
        this.max = max;
        this.display = new TextComponent(String.valueOf(value));

        this.btnMinus = new ButtonComponent("§c-", 0.2f, 0.2f, p -> {
            if (value > min) {
                value--;
                updateDisplay(p, onChange);
            }
        });

        this.btnPlus = new ButtonComponent("§a+", 0.2f, 0.2f, p -> {
            if (value < max) {
                value++;
                updateDisplay(p, onChange);
            }
        });
    }

    /**
     * Updates the text display with the current value and triggers the change callback.
     *
     * @param p The player who changed the value.
     * @param callback The callback function.
     */
    private void updateDisplay(Player p, BiConsumer<Player, Integer> callback) {
        this.display.setText(String.valueOf(value));
        callback.accept(p, value);
    }

    /**
     * Spawns the minus button, value display, and plus button horizontally.
     *
     * @param parent The parent GUI.
     * @param x The central X coordinate.
     * @param y The Y coordinate.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        // Layout: [-]  Value  [+]
        btnMinus.spawn(parent, x - 12, y);
        display.spawn(parent, x, y);
        btnPlus.spawn(parent, x + 12, y);

        entities.addAll(btnMinus.getEntities());
        entities.addAll(display.getEntities());
        entities.addAll(btnPlus.getEntities());
    }

    /**
     * Updates the location of the stepper components.
     *
     * @param x The new central X coordinate.
     * @param y The new Y coordinate.
     */
    @Override
    public void updateLocation(double x, double y) {
        btnMinus.updateLocation(x - 12, y);
        display.updateLocation(x, y);
        btnPlus.updateLocation(x + 12, y);
    }

    /** Interaction handling is done by the sub-buttons */
    @Override public void onClick(Player player) {} // Handled by sub-buttons

    /** Hover handling is done by the sub-buttons */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this stepper, including buttons and text.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
