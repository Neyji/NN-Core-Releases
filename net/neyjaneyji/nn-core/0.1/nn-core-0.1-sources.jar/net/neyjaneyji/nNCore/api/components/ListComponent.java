package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;

/**
 * A component that displays a static bulleted list of strings vertically.
 */
public class ListComponent implements GUIComponent {
    private final List<TextComponent> rows = new ArrayList<>();
    private final List<Entity> entities = new ArrayList<>();
    private final int rowSpacing = 8; // Pixels between rows

    /**
     * Constructs a ListComponent from a list of strings.
     *
     * @param items The list of strings to display.
     */
    public ListComponent(List<String> items) {
        for (String item : items) {
            rows.add(new TextComponent("§f• " + item));
        }
    }

    /**
     * Spawns each row of the list vertically spaced.
     *
     * @param parent The parent GUI.
     * @param x The base X coordinate.
     * @param y The starting Y coordinate (bottom-up depending on engine).
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        double currentY = y;
        for (TextComponent row : rows) {
            row.spawn(parent, x, currentY);
            entities.addAll(row.getEntities());
            currentY += rowSpacing;
        }
    }

    /**
     * Updates the location of each row in the list.
     *
     * @param x The new base X coordinate.
     * @param y The new starting Y coordinate.
     */
    @Override
    public void updateLocation(double x, double y) {
        double currentY = y;
        for (TextComponent row : rows) {
            row.updateLocation(x, currentY);
            currentY += rowSpacing;
        }
    }

    /** No interaction handling directly on the list component */
    @Override public void onClick(Player player) {}

    /** No hover logic directly on the list component */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this list.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
