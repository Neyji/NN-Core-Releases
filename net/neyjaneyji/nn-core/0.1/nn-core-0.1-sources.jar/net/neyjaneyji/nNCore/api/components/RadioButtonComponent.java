package net.neyjaneyji.nNCore.api.components;

import net.neyjaneyji.nNCore.api.GUIComponent;
import net.neyjaneyji.nNCore.api.NNCoreGUI;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * A component representing a group of mutually exclusive options (radio buttons).
 * Only one option can be selected at a time.
 */
public class RadioButtonComponent implements GUIComponent {
    private final List<RadioOption> options = new ArrayList<>();
    private int selectedIndex = -1;
    private final List<Entity> entities = new ArrayList<>();
    private final Consumer<Integer> onSelect;
    private NNCoreGUI parent;

    /**
     * Constructs a RadioButtonComponent.
     *
     * @param labels A list of strings representing the labels for each option.
     * @param onSelect A callback function executed when an option is selected. Provides the selected index.
     */
    public RadioButtonComponent(List<String> labels, Consumer<Integer> onSelect) {
        this.onSelect = onSelect;
        for (int i = 0; i < labels.size(); i++) {
            options.add(new RadioOption(labels.get(i), i));
        }
    }

    /**
     * Internal helper class representing a single radio button option.
     */
    private class RadioOption {
        final TextComponent text;
        final HitboxComponent hitbox;
        final int index;

        RadioOption(String label, int index) {
            this.index = index;
            this.text = new TextComponent("§7○ " + label);
            this.hitbox = new HitboxComponent(0.8f, 0.2f, p -> select(index));
        }

        /**
         * Updates the visual state of the radio button.
         *
         * @param active True if this option is selected.
         */
        void setVisual(boolean active) {
            String label = text.getText().substring(4); // Keep label, swap icon
            text.setText(active ? "§b● " + label : "§7○ " + label);
        }
    }

    /**
     * Selects a specific radio option by index and updates visuals.
     *
     * @param index The index of the option to select.
     */
    public void select(int index) {
        this.selectedIndex = index;
        for (int i = 0; i < options.size(); i++) {
            options.get(i).setVisual(i == index);
        }
        onSelect.accept(index);
    }

    /**
     * Spawns the radio buttons vertically spaced out.
     *
     * @param parent The parent GUI.
     * @param x The base X coordinate.
     * @param y The starting Y coordinate.
     */
    @Override
    public void spawn(NNCoreGUI parent, double x, double y) {
        this.parent = parent;
        double currentY = y;
        for (RadioOption option : options) {
            option.text.spawn(parent, x, currentY);
            option.hitbox.spawn(parent, x, currentY);
            entities.addAll(option.text.getEntities());
            entities.addAll(option.hitbox.getEntities());
            currentY -= 6;
        }
    }

    /**
     * Updates the location of each radio button option.
     *
     * @param x The new base X coordinate.
     * @param y The new starting Y coordinate.
     */
    @Override
    public void updateLocation(double x, double y) {
        double currentY = y;
        for (RadioOption option : options) {
            option.text.updateLocation(x, currentY);
            option.hitbox.updateLocation(x, currentY);
            currentY += 6;
        }
    }

    /** Interaction is handled by individual HitboxComponents */
    @Override public void onClick(Player player) {}

    /** Hover logic is handled by individual HitboxComponents */
    @Override public void onHover(Player player, boolean isHovering) {}

    /**
     * Gets all entities associated with this radio button group.
     *
     * @return A list of the component's Bukkit entities.
     */
    @Override public List<Entity> getEntities() { return entities; }
}
